package core

const (
	Name    = "opensnitch-daemon"
	Version = "1.0.0rc11"
	Author  = "Simone 'evilsocket' Margaritelli"
	Website = "https://github.com/evilsocket/opensnitch"
)
